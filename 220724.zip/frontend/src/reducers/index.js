import { combineReducers } from "redux";
import HEXs from './HEXs';

export default combineReducers({
    HEXs,
})