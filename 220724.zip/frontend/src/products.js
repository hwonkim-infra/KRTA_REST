const products = [
    {
        "attachments": {
            "bucket_struck": 0.86,
            "bucket_heap": 1.23,
            "arm_length": 1200,
            "boom_length": 4500
        },
        "_id": "HX150A_1653724667410",
        "ChangeModel": false,
        "origin": null,
        "model_name": "HX150A",
        "serial_no": 1230,
        "operating_weight": 15230,
        "createdAt": "2022-05-28T07:57:47.414Z",
        "updatedAt": "2022-05-28T07:57:47.414Z",
        "__v": 0
    },
    {
        "attachments": {
            "bucket_struck": 0.34,
            "bucket_heap": 0.56,
            "arm_length": 900,
            "boom_length": 1100
        },
        "_id": "HX85A_1654175714826",
        "ChangeModel": false,
        "origin": null,
        "model_name": "HX85A",
        "serial_no": 230,
        "operating_weight": 8510,
        "createdAt": "2022-06-02T13:15:14.834Z",
        "updatedAt": "2022-06-02T13:15:14.834Z",
        "__v": 0
    }
]

export default products
