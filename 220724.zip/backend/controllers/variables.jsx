model_name, 
serial_no, 
machine_grade, 
operating_weight, 
gearbox, 
overall_length, 
overall_width, 
overall_height, 
ETC, 

ground_clearance, 
shoe_width, 
tumbler_distance, 
track_length, 
track_height, 
track_gap, 
dozer_size, 

engine_name, 
engine_supplier, 
engine_power, 
nominal_rev, 
engine_torque, 
torque_rev, 
engine_cylinder, 


bucket_struck, 
bucket_heap, 
arm_length, 
boom_length, 
quick_coupler_1, 
quick_coupler_weight_1, 
quick_coupler_2, 
quick_coupler_weight_2, 


overall_length_woqc, 
overall_height_woqc, 
digging_reach, 
digging_reach_woqc, 
digging_depth, 
digging_depth_woqc, 
loading_height, 
loading_height_woqc, 


bucket_COS, 
COG_COS, 
tipping_line, 


pump_displacement_swing, 
motor_displacement_swing, 
swing_reduction, 
swing_motor_eff, 




swing_pinion, 
swing_bearing, 
gear_pinion, 
gear_swing_bearing, 
planetary_sun_gear_A1, 
planetary_planet_gear_B1, 
planetary_ring_gear_C1, 
planetary_sun_gear_A2, 
planetary_planet_gear_B2, 
planetary_ring_gear_C2, 


pump_displacement_travel, 
motor_displacement_travel, 
travel_pump_pressure, 
TM_flow_1, 
TM_flow_2, 
TM_mv, 
TM_mt, 
TM_r, 
surface_drag, 
sprocket_radius, 
travel_drag, 
travel_reduc, 
greadability_ref, 
brake_torque, 


travel_sun_gear_S1, 
travel_ring_gear_R1, 
travel_sun_gear_S2, 
travel_ring_gear_R2, 




drawing_exterior, 
drawing_boom, 
drawing_arm, 
drawing_bucket, 
drawing_bucket_capa, 
drawing_Qcouplr, 
drawing_Emission_Certi, 
drawing_Emission_Certi2, 
drawing_EngineCurve, 


swing_reduction_description, 
travel_reduction, 
climb, 
bucket_creep, 