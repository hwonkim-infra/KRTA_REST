import React from "react";
import TagList from "./TagList";

const cStyle = {
  position: "relative",
  display: "inline-block",
  width: "300px",
  border: "1px solid lightblue",
  overflow: "auto",
};
const iStyle = {
  display: "inline-block",
  fontSize: "0.9em",
  margin: "5px",
  width: "90%",
  border: "0",
};

const InputTag = ({ defaultTags, onAddTag, onDeleteTag, placeHolder }) => {
  const onKeyUp = (e) => {
    console.log("🚀 ~ file: InputTag.js ~ line 22 ~ onKeyUp ~ e", e.key);
    if (e.key === "," || e.key === "Enter") {
      let input = e.target.value.trim().split(",");

      if (input.length === 0 || input[0] === "") return;
      onAddTag(input);
      e.target.value = "";
    }
  };

  const _onDeleteTag = (tag) => {
    onDeleteTag(tag);
  };

  return (
    <div style={cStyle}>
      <TagList tags={defaultTags} onDeleteTag={_onDeleteTag} />
      <input
        style={iStyle}
        type="text"
        onKeyUp={(e) => onKeyUp(e)}
        placeholder={placeHolder}
      />
    </div>
  );
};

export default InputTag;
