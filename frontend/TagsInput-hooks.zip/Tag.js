import React, { Fragment } from 'react'

const tagStyle = {
    display: "inline-block", 
    fontSize: "0.9em",
    margin: "5px",
    border: "1px solid lightblue",
    padding: "2px",
    cursor: "pointer"
}


const Tag = ({onDeleteTag, value, color}) => {

    let tag = (
        <div style={tagStyle}>
            <span
            style={{tagStyle, backgroundColor: color}} onClick={e=> onDeleteTag(e, value)}>
                &#x2716;{""}</span>
                {value}

        </div>
    )
  return (
    <Fragment>{tag}</Fragment>
  )
}

export default Tag