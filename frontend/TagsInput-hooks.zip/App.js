import logo from "./logo.svg";
import "./App.css";
import InputTag from "./InputTag";
import { useState } from "react";

function App() {
  const [tags, setTags] = useState(["Tags"]);

  const onAddTag = (tag) => {
    setTags([...tags, tag]);
  };

  const onDeleteTag = (tag) => {
    let remainingTags = tags.filter((t) => {
      return t !== tag;
    });
    setTags([...remainingTags]);
  };

  return (
    <div className="App">
      <InputTag
        onAddTag={onAddTag}
        onDeleteTag={onDeleteTag}
        defaultTags={tags}
        placeholder="enter tags separated by comma"
      />
    </div>
  );
}

export default App;
